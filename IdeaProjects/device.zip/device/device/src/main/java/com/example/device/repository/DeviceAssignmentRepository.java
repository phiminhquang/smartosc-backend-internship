package com.example.device.repository;

import com.example.device.enums.DeviceAssignmentStatus;
import com.example.device.model.DeviceAssignment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

public interface DeviceAssignmentRepository extends JpaRepository<DeviceAssignment, UUID> {

    boolean existsByDeviceId(UUID deviceId);

    boolean existsByUserId(UUID userId);

    boolean existsByDeviceIdAndStatusIn(UUID deviceId, List<DeviceAssignmentStatus> statuses);

    List<DeviceAssignment> findByUserIdOrderByAssignedAtDesc(UUID userId);


    List<DeviceAssignment> findByStatusAndExpectedReturnAtBefore(DeviceAssignmentStatus status, LocalDateTime time  );

    List<DeviceAssignment> findByStatusAndOverdueNotifiedAtIsNull(DeviceAssignmentStatus status);

    List<DeviceAssignment> findByStatusAndReminderNotifiedAtIsNullAndExpectedReturnAtAfterAndExpectedReturnAtBefore(
            DeviceAssignmentStatus status, LocalDateTime start, LocalDateTime end);

    List<DeviceAssignment> findByStatusOrderByExpectedReturnAtAsc(DeviceAssignmentStatus status);

    List<DeviceAssignment> findByUser_EmailOrderByAssignedAtDesc(String email);

    long countByStatus(DeviceAssignmentStatus status);

    @Query("""
    select a
    from DeviceAssignment a
    join fetch a.user
    join fetch a.device
    order by a.assignedAt desc
""")
    List<DeviceAssignment> findAllWithUserAndDevice();

    @Query("""
    select a
    from DeviceAssignment a
    join fetch a.user
    join fetch a.device
    where a.status = :status
    order by a.assignedAt desc
""")
    List<DeviceAssignment> findByStatusWithDetails(
            @Param("status") DeviceAssignmentStatus status
    );

    @Query("""
    select a
    from DeviceAssignment a
    join fetch a.user
    join fetch a.device
    where a.status = :status
      and a.overdueNotifiedAt is null
""")
    List<DeviceAssignment> findOverdueForNotification(
            @Param("status") DeviceAssignmentStatus status
    );

}